public class Abilities {
  void abilityNormal() {}
  void signature() {}
  void ultimate() {}
}